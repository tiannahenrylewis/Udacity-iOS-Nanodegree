//
//  Constants.swift
//  VirtualTourist
//
//  Created by Tianna Henry-Lewis on 2020-05-12.
//  Copyright © 2020 Tianna Henry-Lewis. All rights reserved.
//

import Foundation

class Constants {
    static let FlickrAPIKey = "6eb897135eb699a6e693b652b59ad801"
    static let FlickrAPISecret = "d37f5fe09074d2f5"
}
